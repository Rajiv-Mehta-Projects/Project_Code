package graphs.freshcode;

import java.io.IOException;
import java.util.*;

/*
 * CHANGELOG
 * 
 * 08/05: 
 * - removed incorrect import statements from Vertex.java
 * - in GraphApplic.java main(), added example to show access to edge weight
 * 
 */

public class GraphApplic extends Graph {

	public GraphApplic(long s) {
		super(s);
	}

	// PASS LEVEL
	
	public Integer surfNoJump(Integer v, Integer n) {
		// PRE: v is vertex to start surf; n >= 0
		// POST: surfs the graph randomly for n moves, 
		//       choosing adjacent vertex according to distribution of edge weights
		//       modifies # visits in vertices
		//       returns last visited vertex at end of surfing

		// TODO
		int count = n; // number of steps
		int startV = v; // starting vertex value
			for (int i = 0; i<count;i++) {
			Vertex Vert = getVertex(startV); // Create a new vertex
			Vert.visits++; 
			startV = Vert.getPseudoRandomLink(); // Chooses on edge weights
		}
		return startV;
	}
	
	public Integer surfWithJump(Integer v, Integer n, Double jumpThreshold) {
		// PRE: v is vertex to start surf; n >= 0; 0 <= jumpThreshold <= 1.0
		// POST: surfs the graph randomly for n moves, 
		//       choosing adjacent vertex according to distribution of edge weights if random number is below jumpThreshold, 
		//       choosing any vertex uniformly randomly otherwise;
		//       modifies # visits in vertices
		//       returns last visited vertex at end of surfing

		// TODO
		int count = n; // number of steps
		Integer lastVertex = v; // returning vertex
		Double rand1 = 0.0; //first random below threshold
		Double rand2 = 0.0; // second random number if threshold is less then first random
		for (int i = 0; i<count;i++) {
			Vertex Vert = getVertex(lastVertex); // Creates new vertex
			Vert.visits++; // increments
			rand1 = p.genPseudoRandDouble(); //random number
			if (rand1<jumpThreshold && this.getVertex(lastVertex).adjs.size() > 0) {
				lastVertex = Vert.getPseudoRandomLink();
			} else {
				rand2 = p.genPseudoRandDouble()*numVertices();
				lastVertex = rand2.intValue();
			}
		}
		return lastVertex;
		
	}
	
	public ArrayList<Integer> topN(Integer N) {
		// PRE: none
		// POST: returns N vertices with highest number of visits, in order;
		//       returns all vertices if <N in the graph;
		//       returns vertices ranked 1,..,N,N+1,..,N+k if these k have the
		//         same number of visits as vertex N
		if (N<0 || N==0) {
            return null;
        }
        ArrayList <Integer> arr1 = new ArrayList <Integer>(); //creating first array to store all weighted vertices
        ArrayList<Integer> arr2 = new ArrayList<Integer>(); 
        for (int i = 0; i< numVertices(); i++ ) {
            arr1.add(i);
        }
            int n = arr1.size(); 
            for (int i = 0; i < n-1; i++) { // sorting importance based on weights
                for (int j = 0; j < n-i-1; j++) 
                    if (getVertex(arr1.get(j)).getVisits() < getVertex(arr1.get(j+1)).getVisits())   { // compares importance 
                        Integer temp = arr1.get(j); 
                        arr1.set(j,j+1); 
                        arr1.set(j+1,temp); 
                    } 

            } 
        boolean check = false;
        int comVar = 0;
		for(int i= 0; i < N; i++) {
			check = false;
			arr2.add(arr1.get(i));
			for(int k = i+1; getVertex(arr1.get(k)).getVisits() == getVertex(arr1.get(i)).getVisits(); k++) { 	
					arr2.add(arr1.get(k));
					check = true;
					comVar=k;
			}
			if (check == true) { 
				i = comVar;
			}
		}
         
        // TODO
		System.out.print(arr2);
        return arr2;
	}
	
	// CREDIT LEVEL
	
	public void setVertexWeights () {
		// PRE: -
		// POST: set weights of each vertex v to be v.visits divided by
		//         the total of visits for all vertices
		double total =0.0;
		for (int i = 0; i<numVertices(); i++) {
			total = total + getVertex(i).getVisits();
			for (int j = 0; j<numVertices();j++) {
				getVertex(j).weight = getVertex(j).visits/total;
			}
		}
		// TODO
	}
	
	public void convergenceWeights(Integer dp, Double jumpThreshold) {
		// PRE: dp >= 0 representing number of decimal places
		//		0 <= jumpThreshold <= 1.0
		// POST: web is surfed until all weights are constant to dp decimal places,
		//         for at least one iteration
		ArrayList <Double> PreWeight = new ArrayList <Double>(); // Array list to store the previous weights
		Integer ChangeWeight = 0; //checks if weight changes or not
		Integer ID = surfWithJump(this.getFirstVertexID(),1000,jumpThreshold);
		Double currWeight = 0.0; 
		Double pastWeight = 0.0;
		for (int i = 0; i<this.numVertices();i++) {
			PreWeight.add(this.getVertex(i).getWeight()); // adds the weight of each vertex into the list
		}
		while (ChangeWeight != 1) {
			setVertexWeights();
			for (int i = 0; i< this.numVertices(); i++) {
				currWeight = this.getVertex(i).getWeight() * Math.pow(10, dp);
				pastWeight = PreWeight.get(i) * Math.pow(10, dp);
			}
			if (pastWeight.intValue() == currWeight.intValue()) {
				ChangeWeight = 1;
			} else {
				ChangeWeight = 0;
			}
			for (int i = 0; i< this.numVertices(); i++) {
				PreWeight.set(i,this.getVertex(i).getWeight());
			}
			ID = surfWithJump(ID,1000,jumpThreshold);
		}
		// TODO
	}

	// DISTINCTION LEVEL

	public Integer surfWithJumpUntilHit(Integer v, Integer n, Double jumpThreshold) {
		// PRE: v is vertex to start surf; n >= 0; 0 <= jumpThreshold <= 1.0
		// POST: surfs the graph randomly until visit v for second time (maximum n moves), 
		//       choosing adjacent vertex according to distribution of edge weights if random number is below jumpThreshold, 
		//       choosing any vertex uniformly randomly otherwise;
		//       modifies # visits in vertices
		//       returns number of vertices visited

		// TODO
		Integer vert = v;
		int visits = 0;
		for (int i = 0; i<n; i++) {
			vert = surfWithJump(vert,1,jumpThreshold);
			visits++;
			if (getVertex(vert).equals(getVertex(v))) {
				return visits;
			}
		}
		return 0;
	}

	public Double averageHittingTime(Integer v, Integer n, Integer maxHits, Double jumpThreshold) {
		// PRE: n >= 1 is number of iterations for averaging; maxHits >= 0; 0 <= jumpThreshold <= 1.0
		// POST: returns average number of vertices visited until hitting, across n iterations,
		//         (not including those which stopped because they reached maxHits)
		//       returns 0 if all iterations reached maxVisits
		
		// TODO
		int visits =0; //visits 
		int totVisit = 0; //total visits
		double itr = 0.0; //number of iterations
		double ave = 0.0;  //averageHittingTime
		for( int i=0; i< n; i++) { //iterating n times as mentioned		
			visits = surfWithJumpUntilHit(v, maxHits, jumpThreshold); //gets the visits for each vertex		
			if (visits == maxHits) { //if visit is 0 then it means that maxHit was reached and v was never hit
				itr -=1; //number of iteration that will be divided goes down (excluding it)
			} else {
				itr++; //if v was hit then include the iteration
			}
			totVisit= totVisit + visits; //adds visits
		}
		ave = totVisit/itr; //calculate average
		if (itr <= 0) { //if iteration is <= 0 meaning all vertex reached maxHit
			return 0.0;
		}
		return ave; //returns average.
	}

	public Integer surfWithJumpUntilCover(Integer v, Integer n, Double jumpThreshold) {
		// PRE: v is vertex to start surf; n >= 0; 0 <= jumpThreshold <= 1.0
		// POST: surfs the graph randomly until all vertices visited (with maximum n vertices visited), 
		//       choosing adjacent vertex according to distribution of edge weights if random number is below jumpThreshold, 
		//       choosing any vertex uniformly randomly otherwise;
		//       modifies # visits in vertices
		//       returns number of vertices visited
		
		// TODO
		boolean check = false;
		Integer vert = v;
		Integer visits = 0; 
		for (int i = 0; i<n; i++) {
			vert = surfWithJump(vert,1,jumpThreshold);
			visits++;
			getVertex(vert).marked = true;
		
			for (int j = 0; j< numVertices(); j++ ) {
				if (!getVertex(j).isMarked()) {
					check = false;
				} else {
					check = true;
				}
		}
			if (check == true) {
				return visits;
			}
		}
		return n; 
	}	

	public Double averageCoverTime(Integer n, Integer maxVisits, Double jumpThreshold) {
		// PRE: n >= 1 is number of iterations for averaging; maxVisits >= 0; 0 <= jumpThreshold <= 1.0
		// POST: returns average number of vertices visited until cover, across n iterations,
		//         (not including those which stopped because they reached maxVisits)
		//         randomly selecting start vertex each iteration
		//       returns 0 if all iterations reached maxVisits
		
		// TODO
		int visit =0; 
		int total = 0; 
		double itr = 0.0; 
		double avg = 0.0; 
		Integer vert = 0; 	
		for( int i=0; i< n; i++) { 
			this.setUnmarked(); 
			Double random = p.genPseudoRandDouble(); //generates random number
			vert = random.intValue()*numVertices(); 
			visit = surfWithJumpUntilCover(vert, maxVisits, jumpThreshold); 	
			if (visit == maxVisits) { 
				itr -=1; 
			} else {
				itr++; 
			}
			total = total + visit; 
		}
		avg = total/itr;
		if (itr <= 0) { 
			return 0.0;
		}
		System.out.print(avg);
		return avg; 

	}

	public Integer boostVertex(Integer v, Integer dp) {
		// PRE: v is a vertex in the graph
		// POST: returns a vertex v2 (!= v) such that when edge (v,v2,1.0) is added to the graph,
		//         the weight of v is larger than when edge (v,v3,1.0) is added to the graph
		//         (for any v3), when the graph is surfed to convergence
		//       if there is no such vertex v2 (i.e. v is already connected to all other vertices),
		//         return v
		//       edges are only added if they do not already exist in the graph
		
		// TODO
		ArrayList<Integer> Visits = new ArrayList<Integer>();
		ArrayList<Integer> Index = new ArrayList<Integer>();
		Vertex NewV = getVertex(v);
		int MaxNum = 0;
		for(int i = 0; i <numVertices(); i++) {
		if(!(NewV.getAdjs().containsKey(i) || i==NewV.id)) { 
			NewV.addAdj(i); //found the to be added and adds it to it.
			convergenceWeights(dp, 0.9);
			Visits.add(NewV.getVisits()); //surfs until the last vertex is returned
			Index.add(i); //adds vertex i
			NewV.getAdjs().remove(i); //removes the adjacent neighbour from NewV
			}
		}
		for(int i = 1 ; i <Visits.size();i++) { 
			if (Visits.get(MaxNum) < Visits.get(i)) { //checks the highest visit number.
				MaxNum = i;
			}
		}		
		return Index.get(MaxNum); 
	}
	

	
	
	public static void main(String[] args) {
		GraphApplic g = new GraphApplic(1);

		try {
			g.readWeightedFromFileWSeedAndSetDirected("/C:/Users/meht1/Desktop/University/2020/Sem 1/Comp2010/A2/sample-graphs/assignment-sample-graphs/");
			  // change this path to wherever you store your data files
			g.print();
			System.out.print("weight of edge (1,2): ");
			System.out.println(g.getVertex(1).getAdjs().get(2));			
		}
		catch (IOException e) {
			System.out.println("in exception: " + e);
		}

	}
}
