import React from "react";
import AppScreen from "../components/AppScreen";

function UpdateProfileScreen({ navigation }) {
  return <AppScreen></AppScreen>;
}

export default UpdateProfileScreen;
