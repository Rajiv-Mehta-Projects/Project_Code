#Key notes:
    - Please run application on large Android Device i.e. Google Pixel 5 or S22 Ultra
    - Adding a memory creates the object and displays it on screen and filters out photos for different users
    - Sign in for already made profile:
        Email = N@gmail.com
        Password = 1234